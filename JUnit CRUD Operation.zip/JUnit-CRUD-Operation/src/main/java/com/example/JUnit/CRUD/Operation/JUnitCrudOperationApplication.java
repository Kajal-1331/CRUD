package com.example.JUnit.CRUD.Operation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JUnitCrudOperationApplication {

	public static void main(String[] args) {
		SpringApplication.run(JUnitCrudOperationApplication.class, args);
	}

}
